//
//  MJPerson.h
//  Interview18-autorelease时机
//
//  Created by MJ Lee on 2018/7/3.
//  Copyright © 2018年 MJ Lee. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJPerson : NSObject

@end
